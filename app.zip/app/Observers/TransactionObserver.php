<?php

namespace App\Observers;

use App\Models\InTransaction;
use App\Models\OutTransaction;
use App\Models\Item;
use App\Models\Notification;
use Illuminate\Support\Facades\DB;

class TransactionObserver
{
    /**
     * Jalankan setiap kali transaksi dibuat.
     */
    public function created($trx): void
    {
        // Amankan operasi stok
        DB::transaction(function () use ($trx) {
            if ($trx instanceof InTransaction) {
                // Tambah stok bila transaksi masuk
                $trx->item()->update([
                    'stock' => DB::raw('stock + ' . $trx->qty)
                ]);
            }

            if ($trx instanceof OutTransaction) {
                // Kurangi stok bila transaksi keluar
                $trx->item()->update([
                    'stock' => DB::raw('stock - ' . $trx->qty)
                ]);
            }

            // Ambil ulang item untuk perbandingan stok-minimum
            $item = $trx->item()->lockForUpdate()->first();

            if ($item->stock <= $item->min_stock) {
                Notification::create([
                    'item_id'     => $item->id,
                    'notified_at' => now()->toDateString(),
                    'message'     => "Stok {$item->name} menipis ({$item->stock} / batas {$item->min_stock})",
                    'status'      => 'new',
                ]);
            }
        });
    }
}
