<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    use HasFactory;

    protected $fillable = [
        'item_id',
        'notified_at',
        'message',
        'status',
    ];

    // Relasi ke item (barang)
    public function item()
    {
        return $this->belongsTo(Item::class);
    }
}
