<?php

namespace App\Http\Controllers;

use App\Models\Notification;

class NotificationController extends Controller
{
    public function index()
    {
        $notifications = Notification::with('item')->latest()->paginate(10);
        return view('notifications.index', compact('notifications'));
    }
}
