<?php

namespace App\Http\Controllers;

use App\Models\InTransaction;
use App\Models\Item;
use Illuminate\Http\Request;

class InTransactionController extends Controller
{
    public function index()
    {
        $transactions = InTransaction::with('item')->latest()->paginate(10);
        return view('in.index', compact('transactions'));
    }

    public function create()
    {
        $items = Item::orderBy('name')->get();
        return view('in.create', compact('items'));
    }

    public function store(Request $r)
    {
        $r->validate([
            'item_id' => 'required|exists:items,id',
            'date' => 'required|date',
            'qty' => 'required|integer|min:1',
            'note' => 'nullable|string',
        ]);

        InTransaction::create([
            'item_id' => $r->item_id,
            'user_id' => auth()->id() ?? 1, // default jika belum login
            'date' => $r->date,
            'qty' => $r->qty,
            'note' => $r->note,
        ]);

        return redirect()->route('in-transactions.index')->with('success', 'Transaksi masuk berhasil disimpan');
    }
}
