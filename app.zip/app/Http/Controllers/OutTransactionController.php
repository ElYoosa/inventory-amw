<?php

namespace App\Http\Controllers;

use App\Models\OutTransaction;
use App\Models\Item;
use Illuminate\Http\Request;

class OutTransactionController extends Controller
{
    public function index()
    {
        $transactions = OutTransaction::with('item')->latest()->paginate(10);
        return view('out.index', compact('transactions'));
    }

    public function create()
    {
        $items = Item::orderBy('name')->get();
        return view('out.create', compact('items'));
    }

    public function store(Request $r)
    {
        $r->validate([
            'item_id' => 'required|exists:items,id',
            'date' => 'required|date',
            'qty' => 'required|integer|min:1',
            'receiver' => 'required|string|max:100',
            'note' => 'nullable|string',
        ]);

        OutTransaction::create([
            'item_id' => $r->item_id,
            'user_id' => auth()->id() ?? 1,
            'date' => $r->date,
            'qty' => $r->qty,
            'receiver' => $r->receiver,
            'note' => $r->note,
        ]);

        return redirect()->route('out-transactions.index')->with('success', 'Transaksi keluar berhasil disimpan');
    }
}
