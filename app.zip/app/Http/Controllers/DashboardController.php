<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\InTransaction;
use App\Models\OutTransaction;

class DashboardController extends Controller
{
    public function index()
    {
        return view('dashboard', [
            'totalItems' => Item::count(),
            'inCount' => InTransaction::whereMonth('date', now()->month)->count(),
            'outCount' => OutTransaction::whereMonth('date', now()->month)->count(),
            'lowStocks' => Item::whereColumn('stock', '<=', 'min_stock')->get(),
        ]);
    }
}
