<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\InTransaction;
use App\Models\OutTransaction;
use App\Observers\TransactionObserver;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Daftarkan observer transaksi
        InTransaction::observe(TransactionObserver::class);
        OutTransaction::observe(TransactionObserver::class);
    }
}
